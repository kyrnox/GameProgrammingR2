﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

[RequireComponent(typeof(AudioSource))]
public class PlayerControlla : MonoBehaviour 
{
	public float maxSpeed; 
	public float speed = 100f; //How fast Char is moving.
	public float jumpForce = 150f; // Jumping power for Char

	public bool grounded; //Checks if Char is grounded.
	private Rigidbody2D rigidBody;

	private Animator anim;

	public AudioClip jumping;
	AudioSource audio;


	void Start() 
	{
		rigidBody = gameObject.GetComponent<Rigidbody2D> ();
		anim = gameObject.GetComponent<Animator> ();

		audio = GetComponent<AudioSource> ();
	}
	
	// Update is called once per frame
	void Update() 
	{
		
		anim.SetBool("isGrounded", grounded);
		anim.SetFloat ("Speed", Mathf.Abs(rigidBody.velocity.x));

		float h = Input.GetAxis ("Horizontal");

		if (Input.GetAxis ("Horizontal") < -.001f) 
		{
			transform.localScale = new Vector3 (-2.2f, 2.2f, 2.2f);
		}

		if (grounded) 
		{
			rigidBody.AddForce ((Vector2.right * speed) * h);
		}

		if (Input.GetAxis ("Horizontal") > .001f) 
		{
			transform.localScale = new Vector3 (-2.2f, 2.2f, 2.2f);
		}

		if (Input.GetKeyDown (KeyCode.Space) && grounded) 
		{
			rigidBody.AddForce (Vector2.up * jumpForce);
			audio.PlayOneShot (jumping, 1.0f);
		}

		if (!grounded)
			speed = 75f;
		else
			speed = 300f;
		
	}
}
